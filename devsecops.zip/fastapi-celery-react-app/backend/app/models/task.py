from pydantic import BaseModel
from typing import Optional, Any
from datetime import datetime
from enum import Enum


class TaskStatus(str, Enum):
    PENDING = "PENDING"
    STARTED = "STARTED"
    SUCCESS = "SUCCESS"
    FAILURE = "FAILURE"
    RETRY = "RETRY"
    REVOKED = "REVOKED"


class TaskCreate(BaseModel):
    name: str
    description: Optional[str] = None
    params: Optional[dict] = None


class TaskResponse(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    status: TaskStatus
    result: Optional[Any] = None
    error: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class TaskList(BaseModel):
    tasks: list[TaskResponse]
    total: int
    page: int
    size: int