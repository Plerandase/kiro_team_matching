import time
import random
from celery import current_task
from app.tasks.celery_app import celery_app


@celery_app.task(bind=True)
def sample_task(self, name: str, duration: int = 10):
    """
    샘플 작업 - 지정된 시간 동안 실행되는 작업
    """
    try:
        for i in range(duration):
            time.sleep(1)
            # 진행률 업데이트
            current_task.update_state(
                state="PROGRESS",
                meta={
                    "current": i + 1,
                    "total": duration,
                    "status": f"Processing {name}... ({i + 1}/{duration})"
                }
            )
        
        result = {
            "name": name,
            "duration": duration,
            "message": f"작업 '{name}'이 {duration}초 후에 완료되었습니다!",
            "random_number": random.randint(1, 100)
        }
        
        return result
        
    except Exception as exc:
        current_task.update_state(
            state="FAILURE",
            meta={
                "error": str(exc),
                "status": f"작업 '{name}' 실행 중 오류가 발생했습니다."
            }
        )
        raise exc


@celery_app.task(bind=True)
def data_processing_task(self, data: dict):
    """
    데이터 처리 작업 - 복잡한 데이터 처리를 시뮬레이션
    """
    try:
        total_items = len(data.get("items", []))
        processed_items = []
        
        for i, item in enumerate(data.get("items", [])):
            time.sleep(0.5)  # 처리 시간 시뮬레이션
            
            # 데이터 처리 로직 (예시)
            processed_item = {
                "id": item.get("id"),
                "name": item.get("name", "").upper(),
                "processed_at": time.time(),
                "status": "processed"
            }
            processed_items.append(processed_item)
            
            # 진행률 업데이트
            current_task.update_state(
                state="PROGRESS",
                meta={
                    "current": i + 1,
                    "total": total_items,
                    "status": f"Processing item {i + 1} of {total_items}",
                    "processed_items": len(processed_items)
                }
            )
        
        result = {
            "total_processed": len(processed_items),
            "processed_items": processed_items,
            "message": f"{len(processed_items)}개 항목이 성공적으로 처리되었습니다."
        }
        
        return result
        
    except Exception as exc:
        current_task.update_state(
            state="FAILURE",
            meta={
                "error": str(exc),
                "status": "데이터 처리 중 오류가 발생했습니다."
            }
        )
        raise exc


@celery_app.task(bind=True)
def email_task(self, recipient: str, subject: str, body: str):
    """
    이메일 발송 작업 (시뮬레이션)
    """
    try:
        # 이메일 발송 시뮬레이션
        time.sleep(3)
        
        current_task.update_state(
            state="PROGRESS",
            meta={
                "status": f"Sending email to {recipient}...",
                "current": 1,
                "total": 1
            }
        )
        
        # 실제로는 여기서 이메일 발송 로직을 구현
        result = {
            "recipient": recipient,
            "subject": subject,
            "status": "sent",
            "message": f"이메일이 {recipient}에게 성공적으로 발송되었습니다.",
            "sent_at": time.time()
        }
        
        return result
        
    except Exception as exc:
        current_task.update_state(
            state="FAILURE",
            meta={
                "error": str(exc),
                "status": f"이메일 발송 실패: {recipient}"
            }
        )
        raise exc