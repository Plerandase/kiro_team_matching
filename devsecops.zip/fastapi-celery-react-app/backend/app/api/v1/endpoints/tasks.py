from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from app.models.task import TaskCreate, TaskResponse, TaskStatus
from app.tasks.celery_app import celery_app
from app.tasks import tasks as celery_tasks

router = APIRouter()


@router.post("/", response_model=dict)
async def create_task(task_data: TaskCreate):
    """
    새로운 작업을 생성합니다.
    """
    try:
        # 작업 유형에 따라 다른 Celery 작업 실행
        if task_data.name == "sample":
            duration = task_data.params.get("duration", 10) if task_data.params else 10
            celery_task = celery_tasks.sample_task.delay(
                name=task_data.description or "Sample Task",
                duration=duration
            )
        elif task_data.name == "data_processing":
            data = task_data.params or {"items": []}
            celery_task = celery_tasks.data_processing_task.delay(data)
        elif task_data.name == "email":
            params = task_data.params or {}
            celery_task = celery_tasks.email_task.delay(
                recipient=params.get("recipient", "test@example.com"),
                subject=params.get("subject", "Test Email"),
                body=params.get("body", "This is a test email.")
            )
        else:
            raise HTTPException(status_code=400, detail="지원하지 않는 작업 유형입니다.")
        
        return {
            "task_id": celery_task.id,
            "status": "작업이 생성되었습니다.",
            "message": f"작업 '{task_data.name}'이 큐에 추가되었습니다."
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"작업 생성 실패: {str(e)}")


@router.get("/{task_id}", response_model=dict)
async def get_task_status(task_id: str):
    """
    작업 상태를 조회합니다.
    """
    try:
        task_result = celery_app.AsyncResult(task_id)
        
        if task_result.state == "PENDING":
            response = {
                "task_id": task_id,
                "status": task_result.state,
                "message": "작업이 대기 중입니다."
            }
        elif task_result.state == "PROGRESS":
            response = {
                "task_id": task_id,
                "status": task_result.state,
                "current": task_result.info.get("current", 0),
                "total": task_result.info.get("total", 1),
                "message": task_result.info.get("status", "작업 진행 중...")
            }
        elif task_result.state == "SUCCESS":
            response = {
                "task_id": task_id,
                "status": task_result.state,
                "result": task_result.result,
                "message": "작업이 성공적으로 완료되었습니다."
            }
        else:  # FAILURE
            response = {
                "task_id": task_id,
                "status": task_result.state,
                "error": str(task_result.info),
                "message": "작업 실행 중 오류가 발생했습니다."
            }
        
        return response
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"작업 상태 조회 실패: {str(e)}")


@router.get("/", response_model=dict)
async def list_tasks(
    limit: int = Query(10, ge=1, le=100),
    offset: int = Query(0, ge=0)
):
    """
    활성 작업 목록을 조회합니다.
    """
    try:
        # Celery에서 활성 작업 조회
        inspect = celery_app.control.inspect()
        active_tasks = inspect.active()
        
        if not active_tasks:
            return {
                "tasks": [],
                "total": 0,
                "message": "현재 실행 중인 작업이 없습니다."
            }
        
        # 모든 워커의 활성 작업을 하나의 리스트로 합치기
        all_tasks = []
        for worker, tasks in active_tasks.items():
            for task in tasks:
                task_info = {
                    "task_id": task["id"],
                    "name": task["name"],
                    "worker": worker,
                    "args": task.get("args", []),
                    "kwargs": task.get("kwargs", {}),
                    "time_start": task.get("time_start")
                }
                all_tasks.append(task_info)
        
        # 페이지네이션 적용
        total = len(all_tasks)
        paginated_tasks = all_tasks[offset:offset + limit]
        
        return {
            "tasks": paginated_tasks,
            "total": total,
            "limit": limit,
            "offset": offset,
            "message": f"{total}개의 활성 작업을 찾았습니다."
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"작업 목록 조회 실패: {str(e)}")


@router.delete("/{task_id}", response_model=dict)
async def cancel_task(task_id: str):
    """
    작업을 취소합니다.
    """
    try:
        celery_app.control.revoke(task_id, terminate=True)
        
        return {
            "task_id": task_id,
            "status": "REVOKED",
            "message": "작업이 취소되었습니다."
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"작업 취소 실패: {str(e)}")


@router.get("/types/available", response_model=dict)
async def get_available_task_types():
    """
    사용 가능한 작업 유형 목록을 반환합니다.
    """
    task_types = [
        {
            "name": "sample",
            "description": "샘플 작업 - 지정된 시간 동안 실행",
            "parameters": {
                "duration": "실행 시간 (초, 기본값: 10)"
            }
        },
        {
            "name": "data_processing",
            "description": "데이터 처리 작업 - 배열 데이터 처리",
            "parameters": {
                "items": "처리할 데이터 배열"
            }
        },
        {
            "name": "email",
            "description": "이메일 발송 작업",
            "parameters": {
                "recipient": "수신자 이메일",
                "subject": "이메일 제목",
                "body": "이메일 내용"
            }
        }
    ]
    
    return {
        "task_types": task_types,
        "total": len(task_types),
        "message": "사용 가능한 작업 유형 목록입니다."
    }