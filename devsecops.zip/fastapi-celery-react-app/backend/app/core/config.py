from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # API 설정
    API_V1_STR: str = "/api/v1"
    PROJECT_NAME: str = "FastAPI Celery React App"
    
    # 데이터베이스 설정
    DATABASE_URL: str = "postgresql://postgres:password@db:5432/app_db"
    
    # Redis 설정
    REDIS_URL: str = "redis://redis:6379/0"
    
    # Celery 설정
    CELERY_BROKER_URL: str = "redis://redis:6379/0"
    CELERY_RESULT_BACKEND: str = "redis://redis:6379/0"
    
    # 보안 설정
    SECRET_KEY: str = "your-secret-key-change-in-production"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # CORS 설정
    BACKEND_CORS_ORIGINS: list = ["http://localhost:3000", "http://frontend:3000"]
    
    class Config:
        env_file = ".env"


settings = Settings()