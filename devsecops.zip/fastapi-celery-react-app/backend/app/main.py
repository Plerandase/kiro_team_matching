from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.api.v1.api import api_router


def create_application() -> FastAPI:
    application = FastAPI(
        title=settings.PROJECT_NAME,
        openapi_url=f"{settings.API_V1_STR}/openapi.json"
    )
    
    # CORS 미들웨어 설정
    application.add_middleware(
        CORSMiddleware,
        allow_origins=settings.BACKEND_CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # API 라우터 포함
    application.include_router(api_router, prefix=settings.API_V1_STR)
    
    return application


app = create_application()


@app.get("/health")
async def health_check():
    """헬스체크 엔드포인트"""
    return {"status": "healthy", "service": "fastapi-backend"}


@app.get("/")
async def root():
    """루트 엔드포인트"""
    return {"message": "FastAPI + Celery + React 애플리케이션에 오신 것을 환영합니다!"}