# FastAPI + Celery + React + Terraform 프로젝트

이 프로젝트는 FastAPI 백엔드, Celery 작업 큐, React 프론트엔드, 그리고 Terraform 인프라 구성을 포함한 풀스택 애플리케이션입니다.

## 프로젝트 구조

```
fastapi-celery-react-app/
├── backend/                 # FastAPI 백엔드
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py         # FastAPI 애플리케이션 진입점
│   │   ├── api/            # API 라우터
│   │   ├── core/           # 핵심 설정
│   │   ├── models/         # 데이터 모델
│   │   ├── services/       # 비즈니스 로직
│   │   └── tasks/          # Celery 작업
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/               # React 프론트엔드
│   ├── public/
│   ├── src/
│   ├── package.json
│   └── Dockerfile
├── terraform/              # 인프라 구성
│   ├── main.tf
│   ├── variables.tf
│   └── outputs.tf
├── docker-compose.dev.yml  # 개발 환경 구성
├── docker-compose.yml      # 프로덕션 환경 구성
└── README.md
```

## 빠른 시작

### 개발 환경 실행

1. 저장소 클론 및 디렉토리 이동
```bash
cd fastapi-celery-react-app
```

2. 개발 환경 실행
```bash
docker-compose -f docker-compose.dev.yml up --build
```

3. 서비스 접속
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000
- API 문서: http://localhost:8000/docs
- Flower (Celery 모니터링): http://localhost:5555

### 프로덕션 배포

1. Terraform으로 인프라 구성
```bash
cd terraform
terraform init
terraform plan
terraform apply
```

2. 프로덕션 환경 실행
```bash
docker-compose up --build
```

## 주요 기능

- **FastAPI**: 고성능 Python 웹 프레임워크
- **Celery**: 분산 작업 큐 시스템
- **React**: 모던 프론트엔드 프레임워크
- **Redis**: 메시지 브로커 및 캐시
- **PostgreSQL**: 관계형 데이터베이스
- **Terraform**: 인프라 코드화 (IaC)
- **Docker**: 컨테이너화

## API 엔드포인트

### 작업 관리
- `POST /api/v1/tasks/` - 새 작업 생성
- `GET /api/v1/tasks/{task_id}` - 작업 상태 조회
- `GET /api/v1/tasks/` - 모든 작업 목록

### 헬스체크
- `GET /health` - 서비스 상태 확인

## 환경 변수

개발 환경에서는 `docker-compose.dev.yml`에 정의된 환경 변수를 사용합니다.

프로덕션 환경에서는 다음 환경 변수를 설정해야 합니다:

```bash
DATABASE_URL=postgresql://user:password@localhost/dbname
REDIS_URL=redis://localhost:6379
SECRET_KEY=your-secret-key
```

## 개발 가이드

### 백엔드 개발
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 프론트엔드 개발
```bash
cd frontend
npm install
npm start
```

### Celery 워커 실행
```bash
cd backend
celery -A app.tasks.celery worker --loglevel=info
```

### Celery Flower 모니터링
```bash
cd backend
celery -A app.tasks.celery flower
```

## 테스트

### 백엔드 테스트
```bash
cd backend
pytest
```

### 프론트엔드 테스트
```bash
cd frontend
npm test
```

## 라이센스

MIT License