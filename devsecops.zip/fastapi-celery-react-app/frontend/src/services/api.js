import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const api = axios.create({
  baseURL: `${API_BASE_URL}/api/v1`,
  headers: {
    'Content-Type': 'application/json',
  },
});

// 작업 관련 API
export const taskAPI = {
  // 새 작업 생성
  createTask: async (taskData) => {
    const response = await api.post('/tasks/', taskData);
    return response.data;
  },

  // 작업 상태 조회
  getTaskStatus: async (taskId) => {
    const response = await api.get(`/tasks/${taskId}`);
    return response.data;
  },

  // 작업 목록 조회
  listTasks: async (limit = 10, offset = 0) => {
    const response = await api.get(`/tasks/?limit=${limit}&offset=${offset}`);
    return response.data;
  },

  // 작업 취소
  cancelTask: async (taskId) => {
    const response = await api.delete(`/tasks/${taskId}`);
    return response.data;
  },

  // 사용 가능한 작업 유형 조회
  getAvailableTaskTypes: async () => {
    const response = await api.get('/tasks/types/available');
    return response.data;
  },
};

// 헬스체크 API
export const healthAPI = {
  checkHealth: async () => {
    const response = await axios.get(`${API_BASE_URL}/health`);
    return response.data;
  },
};

export default api;