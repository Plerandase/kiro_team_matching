import React, { useState, useEffect } from 'react';
import {
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Chip,
  Box,
  Alert,
  LinearProgress,
} from '@mui/material';
import { taskAPI } from '../services/api';

const TaskList = () => {
  const [tasks, setTasks] = useState([]);
  const [taskStatuses, setTaskStatuses] = useState({});
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('info');

  useEffect(() => {
    loadTasks();
    
    // 3초마다 작업 상태 업데이트
    const interval = setInterval(updateTaskStatuses, 3000);
    return () => clearInterval(interval);
  }, []);

  const loadTasks = async () => {
    try {
      const response = await taskAPI.listTasks(50, 0);
      setTasks(response.tasks || []);
    } catch (error) {
      showMessage('작업 목록을 불러오는데 실패했습니다.', 'error');
    }
  };

  const updateTaskStatuses = async () => {
    const statusPromises = tasks.map(async (task) => {
      try {
        const status = await taskAPI.getTaskStatus(task.task_id);
        return { taskId: task.task_id, status };
      } catch (error) {
        return { taskId: task.task_id, status: null };
      }
    });

    const statuses = await Promise.all(statusPromises);
    const statusMap = {};
    statuses.forEach(({ taskId, status }) => {
      if (status) {
        statusMap[taskId] = status;
      }
    });
    
    setTaskStatuses(statusMap);
  };

  const showMessage = (text, type = 'info') => {
    setMessage(text);
    setMessageType(type);
    setTimeout(() => setMessage(''), 5000);
  };

  const handleCancelTask = async (taskId) => {
    try {
      const response = await taskAPI.cancelTask(taskId);
      showMessage(response.message, 'success');
      loadTasks();
    } catch (error) {
      showMessage('작업 취소에 실패했습니다.', 'error');
    }
  };

  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'pending':
        return 'warning';
      case 'progress':
        return 'info';
      case 'success':
        return 'success';
      case 'failure':
        return 'error';
      case 'revoked':
        return 'default';
      default:
        return 'default';
    }
  };

  const renderTaskStatus = (task) => {
    const status = taskStatuses[task.task_id];
    
    if (!status) {
      return <Chip label="UNKNOWN" color="default" size="small" />;
    }

    return (
      <Box>
        <Chip 
          label={status.status} 
          color={getStatusColor(status.status)} 
          size="small" 
        />
        
        {status.status === 'PROGRESS' && status.current && status.total && (
          <Box mt={1}>
            <LinearProgress 
              variant="determinate" 
              value={(status.current / status.total) * 100} 
            />
            <Typography variant="caption" display="block">
              {status.current}/{status.total} - {status.message}
            </Typography>
          </Box>
        )}
        
        {status.status === 'SUCCESS' && status.result && (
          <Typography variant="caption" display="block" mt={1}>
            결과: {JSON.stringify(status.result, null, 2).substring(0, 100)}...
          </Typography>
        )}
        
        {status.status === 'FAILURE' && status.error && (
          <Typography variant="caption" color="error" display="block" mt={1}>
            오류: {status.error}
          </Typography>
        )}
      </Box>
    );
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        작업 목록
      </Typography>

      {message && (
        <Alert severity={messageType} sx={{ mb: 2 }}>
          {message}
        </Alert>
      )}

      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>작업 ID</TableCell>
                <TableCell>작업 이름</TableCell>
                <TableCell>워커</TableCell>
                <TableCell>시작 시간</TableCell>
                <TableCell>상태</TableCell>
                <TableCell>작업</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {tasks.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} align="center">
                    <Typography color="textSecondary">
                      현재 실행 중인 작업이 없습니다.
                    </Typography>
                  </TableCell>
                </TableRow>
              ) : (
                tasks.map((task) => (
                  <TableRow key={task.task_id}>
                    <TableCell>
                      <Typography variant="body2" fontFamily="monospace">
                        {task.task_id.substring(0, 8)}...
                      </Typography>
                    </TableCell>
                    <TableCell>{task.name}</TableCell>
                    <TableCell>{task.worker}</TableCell>
                    <TableCell>
                      {task.time_start 
                        ? new Date(task.time_start * 1000).toLocaleString()
                        : '-'
                      }
                    </TableCell>
                    <TableCell>
                      {renderTaskStatus(task)}
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="outlined"
                        color="error"
                        size="small"
                        onClick={() => handleCancelTask(task.task_id)}
                      >
                        취소
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
    </Box>
  );
};

export default TaskList;