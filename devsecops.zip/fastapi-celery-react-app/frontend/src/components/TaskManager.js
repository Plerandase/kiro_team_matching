import React, { useState, useEffect } from 'react';
import {
  Paper,
  Typography,
  TextField,
  Button,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Box,
  Alert,
  Grid,
  Card,
  CardContent,
  LinearProgress,
  Chip,
} from '@mui/material';
import { taskAPI } from '../services/api';

const TaskManager = () => {
  const [taskTypes, setTaskTypes] = useState([]);
  const [selectedTaskType, setSelectedTaskType] = useState('');
  const [taskDescription, setTaskDescription] = useState('');
  const [taskParams, setTaskParams] = useState('{}');
  const [activeTasks, setActiveTasks] = useState([]);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('info');

  useEffect(() => {
    loadTaskTypes();
    loadActiveTasks();
    
    // 5초마다 활성 작업 상태 업데이트
    const interval = setInterval(loadActiveTasks, 5000);
    return () => clearInterval(interval);
  }, []);

  const loadTaskTypes = async () => {
    try {
      const response = await taskAPI.getAvailableTaskTypes();
      setTaskTypes(response.task_types);
    } catch (error) {
      showMessage('작업 유형을 불러오는데 실패했습니다.', 'error');
    }
  };

  const loadActiveTasks = async () => {
    try {
      const response = await taskAPI.listTasks(20, 0);
      setActiveTasks(response.tasks || []);
    } catch (error) {
      console.error('활성 작업 로드 실패:', error);
    }
  };

  const showMessage = (text, type = 'info') => {
    setMessage(text);
    setMessageType(type);
    setTimeout(() => setMessage(''), 5000);
  };

  const handleCreateTask = async () => {
    if (!selectedTaskType) {
      showMessage('작업 유형을 선택해주세요.', 'error');
      return;
    }

    try {
      let params = {};
      if (taskParams.trim()) {
        params = JSON.parse(taskParams);
      }

      const taskData = {
        name: selectedTaskType,
        description: taskDescription || `${selectedTaskType} 작업`,
        params: params,
      };

      const response = await taskAPI.createTask(taskData);
      showMessage(response.message, 'success');
      
      // 폼 초기화
      setTaskDescription('');
      setTaskParams('{}');
      
      // 활성 작업 목록 새로고침
      setTimeout(loadActiveTasks, 1000);
    } catch (error) {
      const errorMessage = error.response?.data?.detail || '작업 생성에 실패했습니다.';
      showMessage(errorMessage, 'error');
    }
  };

  const handleCancelTask = async (taskId) => {
    try {
      const response = await taskAPI.cancelTask(taskId);
      showMessage(response.message, 'success');
      loadActiveTasks();
    } catch (error) {
      showMessage('작업 취소에 실패했습니다.', 'error');
    }
  };

  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'pending':
        return 'warning';
      case 'progress':
        return 'info';
      case 'success':
        return 'success';
      case 'failure':
        return 'error';
      default:
        return 'default';
    }
  };

  const getDefaultParams = (taskType) => {
    switch (taskType) {
      case 'sample':
        return JSON.stringify({ duration: 10 }, null, 2);
      case 'data_processing':
        return JSON.stringify({
          items: [
            { id: 1, name: "item1" },
            { id: 2, name: "item2" },
            { id: 3, name: "item3" }
          ]
        }, null, 2);
      case 'email':
        return JSON.stringify({
          recipient: "test@example.com",
          subject: "테스트 이메일",
          body: "이것은 테스트 이메일입니다."
        }, null, 2);
      default:
        return '{}';
    }
  };

  const handleTaskTypeChange = (event) => {
    const taskType = event.target.value;
    setSelectedTaskType(taskType);
    setTaskParams(getDefaultParams(taskType));
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        작업 관리자
      </Typography>

      {message && (
        <Alert severity={messageType} sx={{ mb: 2 }}>
          {message}
        </Alert>
      )}

      <Grid container spacing={3}>
        {/* 작업 생성 폼 */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              새 작업 생성
            </Typography>

            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel>작업 유형</InputLabel>
              <Select
                value={selectedTaskType}
                onChange={handleTaskTypeChange}
                label="작업 유형"
              >
                {taskTypes.map((type) => (
                  <MenuItem key={type.name} value={type.name}>
                    {type.name} - {type.description}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <TextField
              fullWidth
              label="작업 설명"
              value={taskDescription}
              onChange={(e) => setTaskDescription(e.target.value)}
              sx={{ mb: 2 }}
            />

            <TextField
              fullWidth
              label="작업 매개변수 (JSON)"
              value={taskParams}
              onChange={(e) => setTaskParams(e.target.value)}
              multiline
              rows={6}
              sx={{ mb: 2 }}
              helperText="JSON 형식으로 작업 매개변수를 입력하세요"
            />

            <Button
              variant="contained"
              onClick={handleCreateTask}
              fullWidth
              size="large"
            >
              작업 생성
            </Button>
          </Paper>
        </Grid>

        {/* 활성 작업 목록 */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              활성 작업 ({activeTasks.length})
            </Typography>

            {activeTasks.length === 0 ? (
              <Typography color="textSecondary">
                현재 실행 중인 작업이 없습니다.
              </Typography>
            ) : (
              activeTasks.map((task) => (
                <Card key={task.task_id} sx={{ mb: 2 }}>
                  <CardContent>
                    <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
                      <Typography variant="subtitle1">
                        {task.name}
                      </Typography>
                      <Chip
                        label={task.status || 'ACTIVE'}
                        color={getStatusColor(task.status)}
                        size="small"
                      />
                    </Box>
                    
                    <Typography variant="body2" color="textSecondary" gutterBottom>
                      작업 ID: {task.task_id}
                    </Typography>
                    
                    <Typography variant="body2" color="textSecondary" gutterBottom>
                      워커: {task.worker}
                    </Typography>

                    {task.time_start && (
                      <Typography variant="body2" color="textSecondary" gutterBottom>
                        시작 시간: {new Date(task.time_start * 1000).toLocaleString()}
                      </Typography>
                    )}

                    <Box mt={2}>
                      <Button
                        variant="outlined"
                        color="error"
                        size="small"
                        onClick={() => handleCancelTask(task.task_id)}
                      >
                        작업 취소
                      </Button>
                    </Box>
                  </CardContent>
                </Card>
              ))
            )}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default TaskManager;